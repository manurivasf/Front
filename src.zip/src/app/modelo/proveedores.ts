import { Proveedor } from "./proveedor";

export interface Proveedores {

    items: Proveedor[];
}
