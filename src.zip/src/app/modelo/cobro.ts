export interface Cobro {
    id:number
    idcliente:number
    importe:number
    numfactura:number
    fecha:Date
    formapago:string
    idbanco:number
    estado:boolean
}

