import { Cobro } from "./cobro";

export interface Cobros {
    items: Cobro[]
}
