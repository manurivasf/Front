export interface DatosGraficas {
    name: string;
    value: number;
}
