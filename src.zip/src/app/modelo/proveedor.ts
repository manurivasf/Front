export interface Proveedor {
    id: number;
    nombre: string;
}
