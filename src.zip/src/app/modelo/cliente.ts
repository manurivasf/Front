export interface Cliente {
    id: number;
    ncuenta: string;
    nombre: string;
}
