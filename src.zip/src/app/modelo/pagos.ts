import { Pago } from "./pago";

export interface Pagos {
    items: Pago[]
}
