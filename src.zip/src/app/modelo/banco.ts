export interface Banco {
    id: number;
    nombre: string;
}
