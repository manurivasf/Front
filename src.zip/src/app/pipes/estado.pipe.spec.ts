import { EstadoPipe } from './estado.pipe';

describe('EstadoPipe', () => {
  it('create an instance', () => {
    const pipe = new EstadoPipe();
    expect(pipe).toBeTruthy();
  });
});
